<?php

function ogc_divi_my_sample_function(){
	echo '<p>something diferent</p>';
	//my initials, theme name and function name for readability
}

function ogc_divi_my_sample_function2(){

	$date = date('m/d/Y h:i:s a', time());
	$currentDate = Date('D-m-Y');
	echo '<p>today is: </p>'.$date;
	if(is_page(35)):

	
	echo '<p>'.$currentDate.'</p>';

	endif;
	//my initials, theme name and function name for readability
}